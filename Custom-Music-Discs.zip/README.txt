Custom Music Discs
Built with MC Toolbox Music Disc Maker
Target: Java Edition (.zip resource pack)

Tracks:
- Cat ← france.mp3 (france)

Install: put the .zip in .minecraft/resourcepacks and enable it in Options → Resource Packs.

Notes:
- This pack replaces vanilla disc audio. Use the matching in-game music disc item in a jukebox.
- Long tracks use streamed playback. Very long files may take a moment to start.
- Files never leave your browser while building this pack.